-- ============================================================
--   Nom de la base   :  CINEMA                                
--   Nom de SGBD      :  PostgreSQL                    
--   Date de creation :  30/09/2023                       
-- ============================================================

DROP TABLE IF EXISTS tarif CASCADE;
DROP TABLE IF EXISTS reservation CASCADE;
DROP TABLE IF EXISTS role CASCADE;
DROP TABLE IF EXISTS place CASCADE;
DROP TABLE IF EXISTS seance CASCADE;
DROP TABLE IF EXISTS film CASCADE;
DROP TABLE IF EXISTS categorie_place CASCADE;
DROP TABLE IF EXISTS categorie_seance CASCADE;
DROP TABLE IF EXISTS realisateur CASCADE;
DROP TABLE IF EXISTS acteur CASCADE;

-- ============================================================
--   Table : ACTEUR                                            
-- ============================================================
CREATE TABLE acteur
(
    numero_acteur                   SERIAL                 NOT NULL,
    nom_acteur                      VARCHAR(20)            NOT NULL,
    prenom_acteur                   VARCHAR(20)                    ,
    nation_acteur                   VARCHAR(20)                    ,
    date_de_naissance               DATE                           ,
    CONSTRAINT pk_acteur PRIMARY KEY (numero_acteur)
);

-- ============================================================
--   Table : REALISATEUR                                       
-- ============================================================
CREATE TABLE realisateur
(
    numero_realisateur              SERIAL                 NOT NULL,
    nom_realisateur                 VARCHAR(20)            NOT NULL,
    prenom_realisateur              VARCHAR(20)                    ,
    nation_realisateur              VARCHAR(20)                    ,
    CONSTRAINT pk_realisateur PRIMARY KEY (numero_realisateur)
);

-- ============================================================
--   Table : CATEGORIE_SEANCE                                  
-- ============================================================
CREATE TABLE categorie_seance
(
    categorie_seance                CHAR(1)                NOT NULL,
    type_seance                     VARCHAR(20)                    ,
    CONSTRAINT pk_categorie_seance PRIMARY KEY (categorie_seance)
);

-- ============================================================
--   Table : CATEGORIE_PLACE                                   
-- ============================================================
CREATE TABLE categorie_place
(
    categorie_place                 CHAR(1)                NOT NULL,
    type_place                      VARCHAR(20)                    ,
    CONSTRAINT pk_categorie_place PRIMARY KEY (categorie_place)
);

-- ============================================================
--   Table : FILM                                              
-- ============================================================
CREATE TABLE film
(
    numero_film                     SERIAL                 NOT NULL,
    titre_film                      VARCHAR(30)            NOT NULL,
    date_de_sortie                  DATE                           ,
    duree                           INTEGER                NOT NULL,
    genre                           VARCHAR(20)            NOT NULL,
    numero_realisateur              INTEGER                NOT NULL,
    CONSTRAINT pk_film PRIMARY KEY (numero_film)
);

-- ============================================================
--   Index : FILM_FK1                                          
-- ============================================================
CREATE INDEX film_fk1 ON film (numero_realisateur ASC);

-- ============================================================
--   Table : SEANCE                                            
-- ============================================================
CREATE TABLE seance
(
    numero_seance                   SERIAL                 NOT NULL,
    numero_film                     INTEGER                NOT NULL,
    categorie_seance                CHAR(1)                NOT NULL,
    date_seance                     DATE                           ,
    horaire                         INTEGER                        ,
    CONSTRAINT PK_SEANCE PRIMARY KEY (numero_seance)
);

-- ============================================================
--   Index : SEANCE_FK1                                        
-- ============================================================
CREATE INDEX seance_fk1 ON seance (numero_film ASC);

-- ============================================================
--   Index : SEANCE_FK2                                        
-- ============================================================
CREATE INDEX seance_fk2 ON seance (categorie_seance ASC);

-- ============================================================
--   Table : PLACE                                             
-- ============================================================
CREATE TABLE place
(
    numero_place                    SERIAL                 NOT NULL,
    categorie_place           CHAR(1)                NOT NULL,
    CONSTRAINT pk_place PRIMARY KEY (numero_place)
);

-- ============================================================
--   Index : PLACE_FK1                                         
-- ============================================================
CREATE INDEX place_fk1 ON place (categorie_place ASC);

-- ============================================================
--   Table : ROLE                                              
-- ============================================================
CREATE TABLE role
(
    numero_acteur                   INTEGER                NOT NULL,
    numero_film                     INTEGER                NOT NULL,
    nom_du_role                     VARCHAR(30)                    ,
    CONSTRAINT pk_role PRIMARY KEY (numero_acteur, numero_film)
);

-- ============================================================
--   Table : RESERVATION                                       
-- ============================================================
CREATE TABLE reservation
(
    numero_seance                   INTEGER                NOT NULL,
    numero_place                    INTEGER                NOT NULL,
    nom_spectateur                  VARCHAR(20)                    ,
    CONSTRAINT pk_reservation PRIMARY KEY (numero_seance, numero_place)
);

-- ============================================================
--   Table : TARIF                                             
-- ============================================================
CREATE TABLE tarif
(
    categorie_place           CHAR(1)                NOT NULL,
    categorie_seance          CHAR(1)                NOT NULL,
    prix                            INTEGER                        ,
    CONSTRAINT pk_tarif PRIMARY KEY (categorie_place, categorie_seance)
);

-- Commente pour des raisons pedagogiques :
-- Avoir un film avec un realisateur inexistant pour montrer l'interet des
-- jointures externes droites.
-- alter table FILM
--     add constraint fk1_film foreign key (NUMERO_REALISATEUR)
--        references REALISATEUR (NUMERO_REALISATEUR);

ALTER TABLE seance
    ADD CONSTRAINT fk1_seance FOREIGN KEY (numero_film)
       REFERENCES film (numero_film);

ALTER TABLE seance
    ADD CONSTRAINT fk2_seance FOREIGN KEY (categorie_seance)
       REFERENCES categorie_seance (categorie_seance);

ALTER TABLE place
    ADD CONSTRAINT fk1_place FOREIGN KEY (categorie_place)
       REFERENCES categorie_place (categorie_place);

ALTER TABLE role
    ADD CONSTRAINT fk1_role FOREIGN KEY (numero_acteur)
       REFERENCES acteur (numero_acteur);

ALTER TABLE role
    ADD CONSTRAINT fk2_role FOREIGN KEY (numero_film)
       REFERENCES film (numero_film);

ALTER TABLE reservation
    ADD CONSTRAINT fk1_reservation FOREIGN KEY (numero_seance)
       REFERENCES seance (numero_seance);

ALTER TABLE reservation
    ADD CONSTRAINT fk2_reservation FOREIGN KEY (numero_place)
       REFERENCES place (numero_place);

ALTER TABLE tarif
    ADD CONSTRAINT fk1_tarif FOREIGN KEY (categorie_place)
       REFERENCES categorie_place (categorie_place);

ALTER TABLE tarif
    ADD CONSTRAINT fk2_tarif FOREIGN KEY (categorie_seance)
       REFERENCES categorie_seance (categorie_seance);

